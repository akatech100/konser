@extends('layouts.main')
@section('container')

<h1 class="mb-4">Form Registrasi Penonton</h1>
<form method="post" action="{{ url('/penonton') }}">
    @csrf
    <h4><strong> Identitas Personal</strong> </h4>
    <table class="table table-striped" style="width: 40%;">
        <tr>
            <td>Fullname</td>
            <td>:</td>
            <td>
                @error('name')
                <div class="invalid-feedback"> {{ $message }} </div>
                @enderror
                <input type="text" name="name" placeholder="Input your name" value="{{ old('name') }}"
                    class="form-control @error('name') is-invalid @enderror" required>
            </td>
        </tr>
        <tr>
            <td>Gender</td>
            <td>:</td>
            <td>
                @error('gender')
                <div class="invalid-feedback"> {{ $message }} </div>
                @enderror
                <input type="radio" name="gender" value="Male">Male
                <input type="radio" name="gender" value="Female">Female
            </td>
        </tr>
        <tr>
            <td>Address</td>
            <td>:</td>
            <td>
                @error('address')
                <div class="invalid-feedback"> {{ $message }} </div>
                @enderror
                <input type="text" name="address" placeholder="Input your address" value="{{ old('address') }}"
                    class="form-control @error('address') is-invalid @enderror" required>
            </td>
        </tr>
        <tr>
            <td>Phone</td>
            <td>:</td>
            <td>
                @error('phone')
                <div class="invalid-feedback"> {{ $message }} </div>
                @enderror
                <label><input type="text" name="phone" placeholder="Input your phone" value="{{ old('phone') }}"
                        class="form-control @error('phone') is-invalid @enderror" required>
            </td>
        </tr>
        <tr>
            <td>Email</td>
            <td>:</td>
            <td>
                @error('email')
                <div class="invalid-feedback"> {{ $message }} </div>
                @enderror
                <input type="text" name="email" placeholder="Input your email" value="{{ old('email') }}"
                    class="form-control @error('email') is-invalid @enderror" required>
            </td>
        </tr>
    </table>
    <hr>
    <h4><strong> Identitas Akun</strong> </h4>
    <table class="table table-striped" style="width: 40%;">
        <tr>
            <td>Username</td>
            <td>:</td>
            <td>
                @error('username')
                <div class="invalid-feedback"> {{ $message }} </div>
                @enderror
                <input type="text" name="username" placeholder="Input your Username" value="{{ old('username') }}"
                    class="form-control @error('username') is-invalid @enderror" required>
            </td>
        </tr>

        <tr>
            <td>Password</td>
            <td>:</td>
            <td>
                @error('password')
                <div class="invalid-feedback"> {{ $message }} </div>
                @enderror
                <input type="password" name="password" placeholder="Input your password"
                    class="form-control @error('name') is-invalid @enderror" required>
            </td>
        </tr>


        <tr>
            <td colspan="3"> <input type="submit" value="Submit" class="btn btn-success"></td>
        </tr>
    </table>


</form>

@endsection