<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class PenontonFactory extends Factory
{
    public function definition(): array
    {
        $gender = $this->faker->randomElement(['male', 'female']);

        return [
            'id_user' => 1,
            'name' => $this->faker->name(),
            'gender' => $gender,
            'address' => $this->faker->address(),
            'phone' => $this->faker->phoneNumber(),
            'email' => $this->faker->email()
        ];
    }
}
