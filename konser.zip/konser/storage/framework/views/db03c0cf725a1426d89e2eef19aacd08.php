
<?php $__env->startSection('container'); ?>
<h3 class="mt-4"><?php echo e($title); ?></h3>
<hr>
<div class="container">
    <div class="row">
        <?php if(isset($tiket[0]['id_tiket'])): ?>
        <div class="col-sm-6 mx-auto text-center">
            <h4><br><br><br>Tiket anda telah terferifikasi silahkan bawa tiket untuk check in pada hari pelaksanaan
        </div>
    </div>
    <?php else: ?>
    <form method="post" action="transaksi">
        <?php echo csrf_field(); ?>
        <input type="text" name="input_code" placeholder="Masukkan Kode Pembelian" class="form-control">
        <input type="submit" class="btn btn-success" value="Aktivasi">
    </form>
    <?php endif; ?>

    <div class="row mt-4">
        <div class="col-sm-6 mx-auto ">
            <?php if(isset($tiket[0]['id_tiket'])): ?>
            <table class="table table-striped">
                <tr>
                    <td>ID Tiket</td>
                    <td>:</td>
                    <td><?php echo e($tiket[0]['id_tiket']); ?></td>
                </tr>
                <tr>
                    <td>Nama Penonton</td>
                    <td>:</td>
                    <td> <?php echo e($tiket[0]['name']); ?></td>
                </tr>
                <tr>
                    <td>Phone</td>
                    <td>:</td>
                    <td> <?php echo e($tiket[0]['phone']); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td> <?php echo e($tiket[0]['email']); ?></td>
                </tr>
                <tr>
                    <td>Tgl Pembelian</td>
                    <td>:</td>
                    <td> <?php echo e($tiket[0]['created']); ?></td>
                </tr>
                <tr>
                    <td>Sts Pemakaian</td>
                    <td>:</td>
                    <td>Belum digunakan</td>
                </tr>
            </table>
            <?php else: ?>
            <h3 class="text-center">data tidak ditemukan</h3>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts_userlogin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\konser\resources\views/userlogin/transaksi.blade.php ENDPATH**/ ?>