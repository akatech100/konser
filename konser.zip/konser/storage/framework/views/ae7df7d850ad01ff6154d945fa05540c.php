<?php $__env->startSection('container'); ?>

<center>
    <br><br>
    <img src="/img/tiket.jpg">
    <h1 class="mt-xxl-5">Selamat Datang di <blink_me>Barbarticket.com</blink_me>
    </h1>
    <h4> Pemesanan Tiket Konser Online</h4>
    Dont Have an Account Register Here
    <a href="/penonton/create">Register</a> |
    <a href="/login">Login</a>
</center>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\konser\resources\views/welcome.blade.php ENDPATH**/ ?>