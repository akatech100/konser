
<?php $__env->startSection('container'); ?>

<h1>Semua Penonton</h1>

<!-- will be used to show any messages -->
<?php if(Session::has('message')): ?>
<div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
<?php endif; ?>

<table class="table table-striped table-bordered">
    <thead style="background-color:#d9d9d9;font-weight:bold;" class="text-center">
        <tr>
            <td>No</td>
            <td>Name</td>
            <td>Gender</td>
            <td>Address</td>
            <td>Phone</td>
            <td>Email</td>
            <td>Actions</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $penonton; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key+1); ?></td>
            <td style="white-space: nowrap;"><?php echo e($value->name); ?></td>
            <td><?php echo e($value->gender); ?></td>
            <td><?php echo e($value->address); ?></td>
            <td style="white-space: nowrap;"><?php echo e($value->phone); ?></td>
            <td><?php echo e($value->email); ?></td>
            <td style="white-space: nowrap;">
                <form method="post" action="<?php echo e(url('/penonton/'.$value->id)); ?>">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <a class="btn btn-small btn-success" href="<?php echo e(URL::to('penonton/' . $value->id)); ?>">Show</a>
                    <a class="btn btn-small btn-info" href="<?php echo e(URL::to('penonton/' . $value->id . '/edit')); ?>">Edit</a>
                    <button type="submit" class="btn btn-small btn-danger" href="<?php echo e(URL::to('penonton/' . $value->id)); ?>">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\konser\resources\views/penonton/index.blade.php ENDPATH**/ ?>