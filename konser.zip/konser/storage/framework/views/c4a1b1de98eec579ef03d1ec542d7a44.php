
<?php $__env->startSection('container'); ?>

<h3 class="mt-4"><?php echo e($title); ?></h3>
<hr>
<div class="jumbotron">
    <?php if(isset($penonton->name)): ?>
    <table class="table table-striped" style="width: 40%;">
        <tr>
            <td> <strong>Fullname:</strong></td>
            <td>:</td>
            <td><?php echo e($penonton->name); ?> </td>
        </tr>
        <tr>
            <td> <strong>Gender:</strong> </td>
            <td>:</td>
            <td><?php echo e($penonton->gender); ?> </td>
        </tr>
        <tr>
            <td> <strong>Address:</strong> </td>
            <td>:</td>
            <td><?php echo e($penonton->address); ?> </td>
        </tr>
        <tr>
            <td> <strong>Phone:</strong> </td>
            <td>:</td>
            <td><?php echo e($penonton->phone); ?> </td>
        </tr>
        <tr>
            <td> <strong>Email:</strong> </td>
            <td>:</td>
            <td><?php echo e($penonton->email); ?> </td>
        </tr>
    </table>
    <?php else: ?>
    <h2>Super User / Admin</h2>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts_userlogin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\konser\resources\views/userlogin/dashboard.blade.php ENDPATH**/ ?>